package com.heraizen.cj.numberOperation;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class NumberOperationsTest {

	NumberOperation obj = new NumberOperation();

	@Test
	public void isPrimeTest() {
		assertEquals(true, obj.isPrime(5));
	}

	@Test
	public void isNotPrimeTest() {
		assertEquals(false, obj.isPrime(1));
	}

	@Test
	public void isPrimeNegativeTest() {
		assertEquals(false, obj.isPrime(-10));
	}

	@Test
	public void evenPrimeCheckTest() {
		assertEquals(true, obj.isPrime(2));
	}

	@Test
	public void evenNotPrimeCheckTest() {
		assertEquals(false, obj.isPrime(12));
	}

	//palindrome number 
	
	@Test
	public void isPalindromeTest() {
		assertEquals(true, obj.isPalindrome(121));
	}

	@Test
	public void isNotPalindromeTest() {
		assertEquals(false, obj.isPalindrome(500));
	}
	
	@Test
	public void isNegPalindromeTest() {
		assertEquals(true, obj.isPalindrome(-525));
	}
	
	//palindrome string
	@Test
	public void isNotPalindromeStringTest() {
		assertEquals(false, obj.isPalindrome("Nishad"));
	}
	
	@Test
	public void isPalindromeStringTest() {
		assertEquals(true, obj.isPalindrome("Malayalam"));
	}

	//reverse
	@Test
	public void isNotReverse() {
		assertEquals(753, obj.isReverse(357));
	}
	@Test
	public void isReverse() {
		assertEquals(333, obj.isReverse(333));
	}
	@Test
	public void isNegReverse() {
		assertEquals(323, obj.isReverse(-323));
	}
	
	//Accept arr & key type integer as param and return sum of key.
	@Test
	public void isKeySumOfArray() {
		int[] arrVal = {1,2,3,1};
		assertEquals(4, obj.isArraySumEqualToKey(4, arrVal));
	}
}
