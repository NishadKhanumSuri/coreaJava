package com.heraizen.cj.numberOperation;

public class NumberOperation {

	//prime number
	public boolean isPrime(int num) {

		if (num <= 1)
			return false;

		if (num != 2 && num % 2 == 0)
			return false;

		for (int i = 2; i <= ((int) Math.sqrt(num)); i++) {
			if (num % i == 0)
				return false;
		}

		return true;
	}

	//palindrome number
	public boolean isPalindrome(int negNum) {

		int num = (int)Math.abs(negNum);
		int temp = num;
		int rev = 0;

		while (num > 0) {
		int	pal = num % 10;
			rev = (rev * 10) + pal;
			num = num / 10;
		}

		if (rev == temp)
			return true;

		return false;
	}

	//palindrome string
	public boolean isPalindrome(String str) {

		String pal = "";
		String strLower = str.toLowerCase();
		String temp = strLower;

		for (int i = strLower.length() - 1; i >= 0; i--) {
			pal = pal + strLower.charAt(i);
		}
		if (pal.equals(temp))
			return true;

		return false;
	}

	//reverse
	public int isReverse(int num) {
		int rev = 0;
		int numNeg = ((int)Math.abs(num));
		
		while (numNeg > 0) {
			int pal = numNeg % 10;
			rev = (rev * 10) + pal;
			numNeg = numNeg / 10;
		}

		return rev;
	}
	
	//Accept Array and key of type Integer
	public int isArraySumEqualToKey(int key, int[] arr) {
		
		for(int i = 0; i < arr.length; i++) {
			
			for(int j = i+1; j< arr.length; j++) {
				if(arr[i]+arr[j] == key) {
					
					int arrKey = arr[i] + arr[j];
					return arrKey;
				}
			}
		}
		return 0;
	}
	
}
